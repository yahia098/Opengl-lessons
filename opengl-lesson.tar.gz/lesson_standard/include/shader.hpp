#pragma once
#include "glad/gl.h"
#include <GLFW/glfw3.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
std::string readFile(const std::string &path);
GLuint compileShader(GLenum type, const std::string &source);
